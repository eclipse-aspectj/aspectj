package com.foo;

import org.aspectj.lang.ProceedingJoinPoint;

public final class TestDep
{
	public Object invoke(ProceedingJoinPoint jp) throws Throwable {
		try {
			System.out.println("##### start stopwatch!");
			return jp.proceed();
		} finally {
			System.out.println("##### stop stopwatch!");
		}
	}
}
