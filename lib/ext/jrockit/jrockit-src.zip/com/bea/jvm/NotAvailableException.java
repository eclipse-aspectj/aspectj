package com.bea.jvm;

public class NotAvailableException extends RuntimeException {

}
