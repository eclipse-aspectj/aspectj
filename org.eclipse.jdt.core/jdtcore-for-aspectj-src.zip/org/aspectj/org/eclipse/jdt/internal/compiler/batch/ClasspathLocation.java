/*******************************************************************************
 * Copyright (c) 2000, 2017 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * This is an implementation of an early-draft specification developed under the Java
 * Community Process (JCP) and is made available for testing and evaluation purposes
 * only. The code is not compatible with any specification of the JCP.
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.aspectj.org.eclipse.jdt.internal.compiler.batch;

import java.io.File;
import java.util.Collection;
import java.util.Collections;

import org.aspectj.org.eclipse.jdt.core.compiler.CharOperation;
import org.aspectj.org.eclipse.jdt.internal.compiler.env.AccessRestriction;
import org.aspectj.org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
import org.aspectj.org.eclipse.jdt.internal.compiler.env.IModule;
import org.aspectj.org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
import org.aspectj.org.eclipse.jdt.internal.compiler.util.SuffixConstants;

public abstract class ClasspathLocation implements FileSystem.Classpath,
		SuffixConstants {

	public static final int SOURCE = 1;
	public static final int BINARY = 2;

	String path;
	char[] normalizedPath;
	public AccessRuleSet accessRuleSet;
	IModule module;
	protected boolean isAutoModule;

	public String destinationPath;
		// destination path for compilation units that are reached through this
		// classpath location; the coding is consistent with the one of
		// Main.destinationPath:
		// == null: unspecified, use whatever value is set by the enclosing
		//          context, id est Main;
		// == Main.NONE: absorbent element, do not output class files;
		// else: use as the path of the directory into which class files must
		//       be written.
		// potentially carried by any entry that contains to be compiled files

	protected ClasspathLocation(AccessRuleSet accessRuleSet,
			String destinationPath) {
		this.accessRuleSet = accessRuleSet;
		this.destinationPath = destinationPath;
	}

	/**
	 * Return the first access rule which is violated when accessing a given
	 * type, or null if no 'non accessible' access rule applies.
	 *
	 * @param qualifiedBinaryFileName
	 *            tested type specification, formed as:
	 *            "org.aspectj.org.eclipse.jdt/core/JavaCore.class"; on systems that
	 *            use \ as File.separator, the
	 *            "org.aspectj.org.eclipse.jdt\core\JavaCore.class" is accepted as well
	 * @return the first access rule which is violated when accessing a given
	 *         type, or null if none applies
	 */
	protected AccessRestriction fetchAccessRestriction(String qualifiedBinaryFileName) {
		if (this.accessRuleSet == null)
			return null;
		char [] qualifiedTypeName = qualifiedBinaryFileName.
			substring(0, qualifiedBinaryFileName.length() - SUFFIX_CLASS.length)
			.toCharArray();
		if (File.separatorChar == '\\') {
			CharOperation.replace(qualifiedTypeName, File.separatorChar, '/');
		}
		return this.accessRuleSet.getViolatedRestriction(qualifiedTypeName);
	}
	
	public int getMode() {
		return SOURCE | BINARY;
	}
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.getMode();
		result = prime * result + ((this.path == null) ? 0 : this.path.hashCode());
		return result;
	}
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClasspathLocation other = (ClasspathLocation) obj;
		String localPath = this.getPath();
		String otherPath = other.getPath();
		if (localPath == null) {
			if (otherPath != null)
				return false;
		} else if (!localPath.equals(otherPath))
			return false;
		if (this.getMode() != other.getMode())
			return false;
		return true;
	}
	public String getPath() {
		return this.path;
	}
	public String getDestinationPath() {
		return this.destinationPath;
	}
	
	public void acceptModule(IModule mod) {
		this.module = mod;
		this.isAutoModule = mod.isAutomatic();
	}
	@Override
	public boolean isAutomaticModule() {
		return this.isAutoModule;
	}
	@Override
	public Collection<String> getModuleNames(Collection<String> limitModules) {
		if (this.module != null)
			return Collections.singletonList(String.valueOf(this.module.name()));
		return Collections.emptyList();
	}

	public boolean isPackage(String qualifiedPackageName, String moduleName) {
		return getModulesDeclaringPackage(qualifiedPackageName, moduleName) != null;
	}

	protected char[][] singletonModuleNameIf(boolean condition) {
		if (!condition)
			return null;
		if (this.module != null)
			return new char[][] { this.module.name() };
		return new char[][] { ModuleBinding.UNNAMED };
	}
}
